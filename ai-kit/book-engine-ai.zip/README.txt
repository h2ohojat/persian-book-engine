BookEngine SDK 0.2 - بسته برای تولید کتاب توسط هوش مصنوعی

این بسته، موتور، قرارداد BOOK، راهنمای تألیف، قالب تک‌فایلی و ابزار ساخت را دارد.
AI ابتدا AGENTS.md و ai-kit/AUTHORING-GUIDE.fa.txt را بخواند.

بدون نصب وابستگی، با Node 18 یا بالاتر:
node book-cli.js init books/my-book/BOOK.json
node book-cli.js validate books/my-book/BOOK.json
node book-cli.js build books/my-book/BOOK.json books/my-book/book.html
node book-cli.js editable books/my-book/BOOK.json books/my-book/editable-book.html
node book-cli.js extract books/my-book/book.html books/my-book/project.json
node --test tests/engine.test.js tests/sdk.test.js

در کد JavaScript:
const SDK = require('./src/sdk.js');
const engine = require('./src/engine.js');
const project = SDK.compileBookSpec(BOOK);
const html = engine.renderBook(project);

برای چت بدون ابزار اجرا، ai-kit/01-ai-kit.html و قالب book-template.html را به AI بدهید.
AI فقط بخش BOOK را می‌نویسد؛ کد موتور ثابت می‌ماند.

قالب editable داده کامل تألیف را دارد. خروجی build فقط کتاب مطالعه است.
تست نمونه در books/ai-test قرار دارد؛ منبع آن هنوز نیازمند بررسی مؤلف است.
سرویس مدل و کلید API همراه این بسته نیست. رابط ویرایشگر در پروژه اصلی D:\BookEngine است.
